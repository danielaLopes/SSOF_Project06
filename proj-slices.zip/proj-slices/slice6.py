z(t(a('username')))

# tip: as in any expression, sinks, sanitizers and sources can appear as each other's arguments
  
