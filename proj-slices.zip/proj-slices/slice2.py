nis=b('nis')
q=y("xpto1 %s xpto2" % koneksi)

# tip: arguments of sinks can also be expressions
