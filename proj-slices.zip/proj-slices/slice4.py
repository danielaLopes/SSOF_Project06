nis=b('nis')
q="xpto1" + koneksi
q=y(q,nis)
koneksi = s(koneksi)

# tip: sanitization can only occur if it intercepts a vulnerability
