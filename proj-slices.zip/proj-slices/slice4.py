nis=b('nis')
q="xpto1" + koneksi
q=y(q,nis)
koneksi = s(koneksi)
