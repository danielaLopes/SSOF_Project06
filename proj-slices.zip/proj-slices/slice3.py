koneksi=0
idkelas=c('idk')
com=d()
show_kelas="xpto idkelas"
koneksi=t(com,koneksi)
hasil_kelas=z(show_kelas,koneksi)

# tip: sanitized and unsanitized data can reach sinks simultaneously
