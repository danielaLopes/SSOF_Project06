nis=a('nis')
arg3=""
while nis == "":
      query="xpto" + arg3
      arg3 = arg2
      arg2 = arg1
      arg1 = nis
      indarg = s(indarg,1)
q=x(query)

