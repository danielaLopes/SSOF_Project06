nis=a('nis')
query=""
arg1=""
arg2=""
arg3=""
while nis == "":
      query = query + arg3
      arg3 = arg2
      arg2 = arg1
      arg1 = nis
      indarg = s(indarg,1)
q=x(query)

# tip: different control paths, via number of loops, might encode or not different vulnerablities.
