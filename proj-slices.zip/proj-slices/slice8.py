nis=b(boo)
koneksi=0
if indarg == nis:
   q="xpto1"
else:
   q="xpto2"
w(q,koneksi)
