nis=b(boo)
koneksi=0
if indarg == d(koneksi):
   q = "xpto1 indarg xpto2"
else:
   q="xpto1" + indarg + "xpto2"
q=w(q,koneksi)

# tip: different control paths, via branching, might encode or not different vulnerablities.

