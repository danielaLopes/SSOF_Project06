nis=0
koneksi=""
nis=a('nis')
q="xpto1" + nis + "xpto2"
z(koneksi,q)

# tip: tainted variables can reach a sink via binary operations.
