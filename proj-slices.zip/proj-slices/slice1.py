nis=0
koneksi=0
nis=a('nis')
q="xpto1" + nis + "xpto2"
z(koneksi,q)
