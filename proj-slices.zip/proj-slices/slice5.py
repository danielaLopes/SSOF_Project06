nis=c('nis')
q1="xpto1"
q2=nis + "xpto2"
query=query1 . query2
koneksi=0
q=z(query,koneksi)
