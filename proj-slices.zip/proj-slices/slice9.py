nis=c('nis')
koneksi=0
q=""
while indarg == nis  :
      q=q + "xpto1"
      indarg = t(indarg)
q=w(koneksi,q)

# tip: while loops can encode implicit flows

